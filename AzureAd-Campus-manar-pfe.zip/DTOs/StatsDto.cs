﻿namespace tracerapi.DTOs
{
    public class StatsDto
    {
        public int TachesCount { get; set; }=0;
        public int IncidentsCount { get; set; } = 0;
        public int interventionsCount { get; set; } = 0;
    }
}
